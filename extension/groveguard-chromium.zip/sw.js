// Groveguard service worker (Manifest V3)
importScripts('bloom.js', 'adblock.js', 'bg3.js');
